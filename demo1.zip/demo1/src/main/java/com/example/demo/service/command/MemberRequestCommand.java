package com.example.demo.service.command;

import com.example.demo.model.Member;

/*
service接收controller的物件
 */
public class MemberRequestCommand {
    private String userKey;
    private String userName;
    private String tel;
    private String address;
    private String password;
    private int age;
    private String email;

    // Constructor
    public MemberRequestCommand() {
    }

    // Constructor
    public MemberRequestCommand(String userKey, String userName, String tel, String address, String password, int age, String email) {
        this.userKey = userKey;
        this.userName = userName;
        this.tel = tel;
        this.address = address;
        this.password = password;
        this.age = age;
        this.email = email;
    }

    public String getUserKey() {
        return userKey;
    }

    public void setUserKey(String userKey) {
        this.userKey = userKey;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getTel() {
        return tel;
    }

    public void setTel(String tel) {
        this.tel = tel;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }




}
