package com.example.demo.service.command.in;

import com.example.demo.service.command.MemberRequestCommand;
import com.example.demo.service.command.MemberResponseCommand;

public interface CreaterMemberInterface {
    MemberResponseCommand createMember(MemberRequestCommand request);

}
