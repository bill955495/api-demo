package com.example.demo.service.command.in;

import com.example.demo.service.command.MemberRequestCommand;
import com.example.demo.service.command.MemberResponseCommand;

public interface UpdateMemberInterface {
    MemberResponseCommand updateMember(MemberRequestCommand request) throws Exception;
}
