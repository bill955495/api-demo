package com.example.demo.controller.in;

import com.example.demo.controller.dto.MemberRequest;
import com.example.demo.controller.dto.MemberResponse;
import com.example.demo.service.command.in.CreaterMemberInterface;
import com.example.demo.service.command.MemberRequestCommand;
import com.example.demo.service.command.MemberResponseCommand;
import com.example.demo.service.command.in.UpdateMemberInterface;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/member")
@Validated //驗證
public class MemberController {
    @Autowired
    private CreaterMemberInterface createrMemberService;
    @Autowired
    private UpdateMemberInterface updateMemberService;

    @PostMapping("/register/v1")//註冊會員
    public ResponseEntity<?> registerMember(@RequestBody @Valid MemberRequest request) {
        // 将 MemberRequest 转换为 MemberRequestCmd
        MemberRequestCommand requestCommand = convertToMemberRequestCmd(request);

        try {
            // 调用 service 创建会员
            MemberResponseCommand responseCommand = createrMemberService.createMember(requestCommand);
            // 将 responseCommand 转换为 responseDto
            MemberResponse responseDto = convertToMemberResponse(responseCommand);
            return new ResponseEntity<>(responseDto, HttpStatus.OK);
        } catch (RuntimeException e) {

            Map<String, Object> errorResponse = createErrorResponse();
            return new ResponseEntity<>(errorResponse, HttpStatus.INTERNAL_SERVER_ERROR);

        }
    }

    @PutMapping("/edit/v1")//編輯會員
    public ResponseEntity<?> editMember(@RequestBody @Valid MemberRequest request) {
        MemberRequestCommand requestCommand = convertToMemberRequestCmd(request);

        try {
            MemberResponseCommand responseCommand = updateMemberService.updateMember(requestCommand);
            MemberResponse responseDto = convertToMemberResponse(responseCommand);
            return new ResponseEntity<>(responseDto, HttpStatus.OK);
        } catch (Exception e) {
            Map<String, Object> errorResponse = updateErrorResponse();
            return new ResponseEntity<>(errorResponse, HttpStatus.INTERNAL_SERVER_ERROR);
        }

    }


    // 轉換 request DTO 到 MemberRequestCmd
    private MemberRequestCommand convertToMemberRequestCmd(MemberRequest requestDto) {
        return new MemberRequestCommand(
                requestDto.getUserKey(),
                requestDto.getUserName(),
                requestDto.getTel(),
                requestDto.getAddress(),
                requestDto.getPassword(),
                requestDto.getAge(),
                requestDto.getEmail()
        );
    }

    // 轉換 MemberResponseCmd 到 responseDTO
    private MemberResponse convertToMemberResponse(MemberResponseCommand responseCommand) {
        return new MemberResponse(
                responseCommand.getUserKey(),
                responseCommand.getUserName(),
                responseCommand.getTel()
        );
    }

    public Map<String, Object> createErrorResponse() {
        Map<String, Object> errorResponse = new HashMap<>();
        errorResponse.put("message", "會員創建失敗");
        errorResponse.put("errorCode", "MEMBER_CREATION_FAILED");
        errorResponse.put("data", null); // 这里设置了 data 为 null

        return errorResponse;
    }

    public Map<String, Object> updateErrorResponse() {
        Map<String, Object> errorResponse = new HashMap<>();
        errorResponse.put("message", "會員編號不存在，更新失敗");
        errorResponse.put("errorCode", "MEMBER_UPDATE_FAILED");
        errorResponse.put("data", null); // 这里设置了 data 为 null

        return errorResponse;
    }


}


