package com.example.demo.service.command.in;

import com.example.demo.model.Member;
import com.example.demo.service.command.MemberRequestCommand;
import com.example.demo.service.command.MemberResponseCommand;
import com.example.demo.service.command.out.MemberRepostioryInterface;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UpdateMemberServiceImpl implements UpdateMemberInterface {
    @Autowired
    private MemberRepostioryInterface memberRepository;

    @Override
    //更新資料
    public MemberResponseCommand updateMember(MemberRequestCommand request) throws Exception {
        if (isUserKeyTaken(request.getUserKey())) {//如果會員存在
            Member member = convertToMember(request);//轉換資料給Entity
            memberRepository.save(member);// 儲存會員資料到資料庫中
            return convertToMemberResponseCmd(member);//回傳會員修改資料
        } else {
            throw new Exception("會員不存在，無法修改");
        }

    }

    // 判斷 UserKey 是否存在
    public boolean isUserKeyTaken(String userKey) {
        return memberRepository.existsByUserKey(userKey);//existsByUserKey判斷userKey是否存在
    }

    // 轉換 MemberRequestCmd 到 Entity
    private Member convertToMember(MemberRequestCommand requestCommand) {
        Member member = new Member();
        member.setUserKey(requestCommand.getUserKey());
        member.setUserName(requestCommand.getUserName());
        member.setTel(requestCommand.getTel());
        member.setAddress(requestCommand.getAddress());
        member.setPassword(requestCommand.getPassword());
        member.setAge(requestCommand.getAge());
        member.setEmail(requestCommand.getEmail());
        return member;
    }

    // 轉換 Entity 到 MemberResponseCmd
    public MemberResponseCommand convertToMemberResponseCmd(Member member) {
        return new MemberResponseCommand(
                member.getUserKey(),
                member.getUserName(),
                member.getTel()
        );
    }
}
