package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableScheduling
public class Demo1Application {

    public static void main(String[] args) {

        SpringApplication.run(Demo1Application.class, args);

//        try {
//
//
//            if (args.length > 0) {
//                for (int i = 0; i < args.length; i++) {
//                    System.out.println("輸入參數:" + args[i]);
//                }
//            }
//            else {
//                throw new RuntimeException("未輸入參數");
//            }
//        }catch (Exception e){
//            System.err.println("错误: " + e.getMessage());
//
//        }
    }

}
