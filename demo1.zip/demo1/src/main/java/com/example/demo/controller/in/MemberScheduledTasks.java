package com.example.demo.controller.in;


import org.springframework.stereotype.Component;

@Component
public class MemberScheduledTasks {
    private final long second = 1000 * 1;
    private final long INTERVAL_IN_SECONDS = 10 * second;//間隔秒數

//
//    public MemberScheduledTasks(MemberService memberService) {
//        this.memberService = memberService;
//    }
//
//
//    @Scheduled(fixedRate = INTERVAL_IN_SECONDS) // 每隔幾秒执行一次
//    public void reportCurrentTime() {//回傳當前時間
//        System.out.println("Current time is " + new Date());
//    }
//
//    @Scheduled(fixedRate = INTERVAL_IN_SECONDS) // 每隔幾秒执行一次
//    public void sendNameScheduled() {//發送會員姓名排程
//        MemberRequestCommand requestCmd = new MemberRequestCommand();
//        MemberResponseCommand responseCmd = memberService.sendMemberName(requestCmd);
//        System.out.println("Member name is " + responseCmd.getUserName());
//    }


}
