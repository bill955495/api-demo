package com.example.demo.model;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface MemberRepository extends JpaRepository<Member, Long> {

    // 檢查資料庫中是否存在與指定的 userKey 或 userName 相同的會員資料
    boolean existsByUserKey(String userKey);

    String findByUserKey(String userKey);

}
