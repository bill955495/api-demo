package com.example.demo.controller.dto;

import jakarta.validation.constraints.*;

//@Getter
public class MemberRequest {
    @NotBlank(message = "此欄位不能為空")
    @Size(min = 10, max = 10, message = "長度必需是10")
    private String userKey;
    @NotBlank(message = "此欄位不能為空")
    private String userName;

    private String tel;

    private String address;
    @NotBlank(message = "此欄位不能為空")
    private String password;
    @Min(value = 1, message = "最小為1")
    @Max(value = 120, message = "最大為120")
    private int age;
    @NotBlank(message = "此欄位不能為空")
    @Email(message = "email格式部正確")
    private String email;

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getUserKey() {
        return userKey;
    }

    public void setUserKey(String userKey) {
        this.userKey = userKey;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getTel() {
        return tel;
    }

    public void setTel(String tel) {
        this.tel = tel;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}
