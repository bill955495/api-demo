package com.example.demo.service.command;

import com.example.demo.model.Member;

/*
service回傳給controller的物件
 */
public class MemberResponseCommand {
    private String userKey;
    private String userName;
    private String tel;

    // Constructor
    public MemberResponseCommand() {
    }

    // Constructor
    public MemberResponseCommand(String userKey, String userName, String tel) {
        this.userKey = userKey;
        this.userName = userName;
        this.tel = tel;
    }

    public String getUserKey() {
        return userKey;
    }

    public void setUserKey(String userKey) {
        this.userKey = userKey;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getTel() {
        return tel;
    }

    public void setTel(String tel) {
        this.tel = tel;
    }



}
